
Successfully packaged 4 files: 63,040,830 B


For Level 1 (BCD) and Level 2 (PBCD) data, please see the files
called r*/QualityAnalysis*.README for more detailed information
about these data and the Spitzer mission.
For Inventory Search results (e.g., Legacy data deliveries),
please see the corresponding delivery document from the
Legacy teams themselves, available on the IRSA website
(http://irsa.ipac.caltech.edu/Missions/spitzer.html)
